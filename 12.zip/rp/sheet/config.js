// Ballas RP Sheet — конфиг
// ВАЖНО: сюда один раз вписывается URL вашего Apps Script Web App (…/exec)
// Пользователю на сайте ничего вводить не нужно.

// Обнови ссылку, если сделаешь новый деплой.
window.BALLAS_SHEETS_ENDPOINT = 'https://script.google.com/macros/s/AKfycbzvcMGZ6UQy5RAS8KvWHw31mhIvnnLZ5stdgusmOyNMZ9iKOzAQwEMGk3S60W5WZY9-Cw/exec';
